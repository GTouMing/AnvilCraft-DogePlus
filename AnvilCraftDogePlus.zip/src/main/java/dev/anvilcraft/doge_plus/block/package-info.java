@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
package dev.anvilcraft.doge_plus.block;

import net.minecraft.MethodsReturnNonnullByDefault;

import javax.annotation.ParametersAreNonnullByDefault;