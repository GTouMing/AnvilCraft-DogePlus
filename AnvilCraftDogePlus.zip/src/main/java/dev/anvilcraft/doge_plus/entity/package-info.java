@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
package dev.anvilcraft.doge_plus.entity;

import net.minecraft.MethodsReturnNonnullByDefault;

import javax.annotation.ParametersAreNonnullByDefault;